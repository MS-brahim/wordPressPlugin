<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://wppb.me/
 * @since      1.0.0
 *
 * @package    Him_design
 * @subpackage Him_design/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Him_design
 * @subpackage Him_design/includes
 * @author     Plug designer <plug_designer >
 */
class Him_design_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
